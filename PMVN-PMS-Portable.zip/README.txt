=====================================================================
          PMVN SMART HOSPITALITY SUITE - BAN PORTABLE (1-CLICK)
             PhuongMinh Software  |  Website: omoshop.live
                    Hotline / Zalo: 0941.204.125
=====================================================================

1. CACH CHAY (KHONG CAN CAI DAT NODE.JS HAY PHAN MEM PHU):
   - Copy toan bo thu muc nay sang bat ky may tinh Windows nao
     (O D:, Desktop, hoac chay truc tiep tren USB).
   - Nhap dup chuot vao file duy nhat:
         >>>  RunPMSHotel.bat  <<<
   - Trinh duyet se tu dong mo tai: http://localhost:3000

2. KET NOI DIEN THOAI / IPAD CUNG MANG WI-FI:
   - Xem dia chi IP mang LAN hien thi tren cua so RunPMSHotel.bat
     (vi du: http://192.168.1.100:3000) va mo tren trinh duyet dien thoai.

3. TAI KHOAN DANG NHAP MAC DINH:
   - Quan tri vien: admin / pmvn1234
   - Le tan:        letan / pmvn1234
   (Vui long doi mat khau trong muc Cai Dat sau khi dang nhap lan dau.)

4. SAO LUU DU LIEU:
   - Toan bo du lieu phong, hoa don, khach hang nam gon trong thu muc:
         Data\pmvn.db
   - Chi can copy thu muc Data la giu nguyen 100% du lieu khi chuyen may.
=====================================================================
