// Service worker tối giản: chỉ đăng ký fetch handler để Chrome cho phép "Cài đặt ứng dụng".
// Không cache gì để tránh phục vụ nội dung cũ — dữ liệu luôn lấy từ server nội bộ.
self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (event) => {
  // Chỉ cần tồn tại fetch listener để Chrome cho phép cài đặt PWA.
  // Không gọi respondWith() nên request đi thẳng ra network, không cache, không đổi hành vi.
  void event;
});
